# Solutions - Lab 5:

Please note you may need to update path to Common Folder in the html files. 

## Try This:

1. Try this: In the fragment shader we can also multiply the vertex colours from the application by the values in the texture image resulting in a blended effect. Try this line of code in the fragment shader to calculate the fragment colour: `gl_FragColor = fColor * texture2D ( texture , fTexCoord );` and also try to alter the value of the colours that the application chooses for each vertex. What happens to the cube? [Solution](./TryThis/TryThisAnswers.txt)

## Exercises:
1. In the CubeTexture demo try changing the texture image with a different one. And also try experimenting with textures having different resolutions and aspect ratio. [Solution](./Exercise-1/Ex1-CubeTexture/)
2. In the CubeTexture demo can you change the texture mapping to use only part of the (u, v) range, for example (0.0, 0.5), like in Figure 5.2? [Solution](./Exercise-2/Ex2-CubeTexture/)
3. Try manipulating the depth information defined in honolulu256 and see its
effects. [Solution](./Exercise-3/Ex3-solution.txt)
4. Can you import the cushion.png image and use that one as bump map in our exercise? [Solution](./Exercise-4/Ex4-BumpMap/)
