# Solutions - Lab 6:

Please note you may need to update path to Common Folder in the html files. 

## Try This:

1. Try this: What happens if you change the value of diffuse to something like 3.0? [Solution](./TryThis/TryThisAnswers.txt)

## Exercises:
1. In the ParticleDiffusion try changing the code so that only half of the particle gets rendered with the magenta colour and the other half is rendered as a different colour (e.g., blue) to obtain an effect similar to the one in Figure 6.3 left. [Solution](./Exercise-1/Ex1-2ColourParticleDiffusion/)
2. In ParticleDiffusion the initial position of the particles is assigned randomly. Can you create a single spawning point instead? See Figure 6.3, Right. [Solution](./Exercise-2/Ex2-SpawnParticleDiffusion/)
